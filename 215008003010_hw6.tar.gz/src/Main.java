public class Main {

  public static void main(String[] args) {
    eShop shop = new eShop();
    Menu menu = new Menu();
    shop.openShop();
    menu.run();
  }
}
