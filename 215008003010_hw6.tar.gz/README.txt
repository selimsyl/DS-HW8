I have used to create products and trader users data from e-commerce-samples.csv file.

Example Login as a customer
id : 10000000
pw : 111111

Example Login as a trader
id : 10000001
pw : 111111

Only small part of homework is done. A customer can login to sytem, make searches and sort search results.


